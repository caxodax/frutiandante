// Configuración oficial de Firebase para Frutiandante
export const firebaseConfig = {
  apiKey: "AIzaSyBRLGuZol4LEbrqDL2H8RhXtiI1zn3puwY",
  authDomain: "frutiandante.firebaseapp.com",
  projectId: "frutiandante",
  storageBucket: "frutiandante.firebasestorage.app",
  messagingSenderId: "450593359885",
  appId: "1:450593359885:web:f3bba6f6ff240629e7ad44"
};
