'use client';

import { useState } from 'react';
import { useCollection, useFirestore, useUser, useDoc } from '@/firebase';
import { collection, query, orderBy, doc, updateDoc } from 'firebase/firestore';
import { useMemoFirebase } from '@/firebase/firestore/use-collection';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Loader2, Eye, CheckCircle2, XCircle, Clock, Landmark, ShoppingBag, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError, type SecurityRuleContext } from '@/firebase/errors';

export default function PaginaAdminPedidos() {
  const firestore = useFirestore();
  const { user, loading: userLoading } = useUser();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [pedidoSeleccionado, setPedidoSeleccionado] = useState<any>(null);

  const userProfileRef = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return doc(firestore, 'users', user.uid);
  }, [firestore, user]);

  const { data: userProfile, loading: loadingProfile } = useDoc(userProfileRef);
  
  const esAdmin = !loadingProfile && userProfile && (userProfile as any).role === 'admin';

  const ordersQuery = useMemoFirebase(() => {
    // Gating defensivo absoluto
    if (!firestore || !user || !esAdmin) return null;
    return query(collection(firestore, 'orders'), orderBy('created_at', 'desc'));
  }, [firestore, user, esAdmin]);

  const { data: orders, loading: loadingOrders, error: ordersError } = useCollection(ordersQuery);

  const pedidosFiltrados = (orders || []).filter((o: any) => 
    o.cliente?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    o.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const actualizarEstado = async (id: string, nuevoEstado: string) => {
    if (!firestore) return;
    const docRef = doc(firestore, 'orders', id);
    
    updateDoc(docRef, { estado: nuevoEstado })
      .then(() => {
        toast({ title: "Estado actualizado", description: `El pedido ahora está ${nuevoEstado}.` });
        if (pedidoSeleccionado?.id === id) {
          setPedidoSeleccionado({ ...pedidoSeleccionado, estado: nuevoEstado });
        }
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: { estado: nuevoEstado },
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  const getBadgeEstado = (estado: string) => {
    switch (estado) {
      case 'completado': return <Badge className="bg-emerald-500 hover:bg-emerald-600">Completado</Badge>;
      case 'cancelado': return <Badge variant="destructive">Cancelado</Badge>;
      default: return <Badge variant="secondary" className="bg-orange-100 text-orange-700 border-none">Pendiente</Badge>;
    }
  };

  if (userLoading || loadingProfile) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Verificando Credenciales...</p>
      </div>
    );
  }

  if (!esAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
        <AlertCircle className="h-16 w-16 text-destructive mb-2" />
        <h2 className="text-2xl font-black font-headline">Acceso No Autorizado</h2>
        <p className="text-slate-500 max-w-md">No tienes los permisos necesarios para gestionar los pedidos de Frutiandante.</p>
        <Button asChild className="mt-4 rounded-xl">
          <a href="/">Volver al Inicio</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="shadow-lg border-none rounded-3xl overflow-hidden">
        <CardHeader className="bg-slate-50/50 p-8 border-b">
          <div>
            <CardTitle className="font-headline text-3xl font-black text-slate-900">Gestión de Pedidos</CardTitle>
            <CardDescription>Visualización global de ventas de Frutiandante.</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="p-8">
          <div className="mb-8 relative w-full sm:w-1/2">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <Input 
              placeholder="Buscar por cliente o ID de pedido..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 h-12 rounded-xl bg-slate-50 border-slate-100" 
            />
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-100">
            {loadingOrders ? (
              <div className="flex justify-center py-20">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : ordersError ? (
              <div className="text-center py-10 text-destructive font-bold">
                Error al cargar pedidos. Verifica tu conexión o permisos.
              </div>
            ) : (
              <Table>
                <TableHeader className="bg-slate-50/50">
                  <TableRow>
                    <TableHead className="font-bold">ID / Fecha</TableHead>
                    <TableHead className="font-bold">Cliente</TableHead>
                    <TableHead className="font-bold">Total</TableHead>
                    <TableHead className="font-bold">Pago</TableHead>
                    <TableHead className="font-bold">Estado</TableHead>
                    <TableHead className="text-right font-bold">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pedidosFiltrados.map((pedido: any) => (
                    <TableRow key={pedido.id} className="hover:bg-slate-50/50 transition-colors">
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-mono text-xs text-slate-400">#{pedido.id.substring(0, 8)}</span>
                          <span className="text-xs font-medium">
                            {pedido.created_at?.seconds 
                              ? format(new Date(pedido.created_at.seconds * 1000), "dd/MM/yy HH:mm", { locale: es })
                              : '---'}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="font-bold text-slate-900">{pedido.cliente || 'Anónimo'}</TableCell>
                      <TableCell className="font-black text-primary">${pedido.total?.toLocaleString('es-CL')}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs">
                          {pedido.metodoPago === 'transferencia' ? <Landmark className="h-3 w-3" /> : <ShoppingBag className="h-3 w-3" />}
                          <span className="capitalize">{pedido.metodoPago}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getBadgeEstado(pedido.estado)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="rounded-xl" onClick={() => setPedidoSeleccionado(pedido)}>
                          <Eye className="h-4 w-4 mr-2" /> Ver Detalles
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!pedidoSeleccionado} onOpenChange={() => setPedidoSeleccionado(null)}>
        <DialogContent className="max-w-2xl rounded-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black font-headline">Pedido #{pedidoSeleccionado?.id.substring(0, 8)}</DialogTitle>
            <DialogDescription>Gestión administrativa del pedido.</DialogDescription>
          </DialogHeader>
          
          {pedidoSeleccionado && (
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cliente</p>
                  <p className="font-bold">{pedidoSeleccionado.cliente}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Método de Pago</p>
                  <p className="font-bold capitalize">{pedidoSeleccionado.metodoPago}</p>
                </div>
              </div>

              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Detalle de Productos</p>
                <div className="space-y-2">
                  {pedidoSeleccionado.items?.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between items-center text-sm border-b border-slate-100 pb-2">
                      <span>{item.nombre} <span className="text-slate-400">x{item.cant}</span></span>
                      <span className="font-bold">${(item.precio * item.cant).toLocaleString('es-CL')}</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between items-center mt-4 pt-4 border-t-2 border-slate-900">
                  <span className="text-lg font-black">TOTAL</span>
                  <span className="text-2xl font-black text-primary">${pedidoSeleccionado.total?.toLocaleString('es-CL')}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 pt-4 border-t">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                  onClick={() => actualizarEstado(pedidoSeleccionado.id, 'completado')}
                >
                  <CheckCircle2 className="h-4 w-4 mr-2" /> Marcar Completado
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="rounded-xl border-orange-200 text-orange-700 hover:bg-orange-50"
                  onClick={() => actualizarEstado(pedidoSeleccionado.id, 'pendiente')}
                >
                  <Clock className="h-4 w-4 mr-2" /> Pendiente
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="rounded-xl border-destructive/20 text-destructive hover:bg-destructive/10"
                  onClick={() => actualizarEstado(pedidoSeleccionado.id, 'cancelado')}
                >
                  <XCircle className="h-4 w-4 mr-2" /> Cancelar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
