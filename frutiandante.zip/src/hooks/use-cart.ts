// Este archivo ha sido reemplazado por use-cart.tsx para permitir sintaxis JSX.
export {};
