# Firebase Studio (en Español)

Este es un proyecto de inicio de NextJS en Firebase Studio.

Para comenzar, echa un vistazo a `src/app/page.tsx`.
