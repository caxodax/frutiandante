(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_b4714161._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_b4714161._.js",
  "chunks": [
    "static/chunks/src_app_globals_b805903d.css",
    "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
    "static/chunks/d9ef2_@firebase_auth_dist_esm2017_c7c5299a._.js",
    "static/chunks/node_modules_@firebase_storage_dist_index_esm2017_b3a08d2a.js",
    "static/chunks/node_modules_fe36fda2._.js",
    "static/chunks/src_b831b640._.js"
  ],
  "source": "dynamic"
});
